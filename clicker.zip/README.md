# My 1st Clicker

It's a very basic clicker which i did with a low js knowledge and zero html knowlegde.
It's my very first project which i did myself (and second at all).
What it contains?
- Two upgrades: one increases your gain by 1, other increases that first upgrade boost for 10%.
- Few bugs: they're always exist, ye?
Will do it have update?
Probably. I should learn more js and html for it.

0.0 desc xd  - me at 21:32 09.07.2023