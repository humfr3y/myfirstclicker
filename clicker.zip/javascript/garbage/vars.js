var n1 = 10;
var n2 = 36;
var n3 = -20;
var n4 = 0;
var s1 = "negri";
var s2 = "poop";
var b1 = true;
var b2 = false;
var r1, r2, r3, r4;

console.log("Результат + : " + (n1 + n2));
console.log("Результат - : " + (n1 - n2));
console.log("Результат * : " + (n3 * n2));
console.log("Результат / : " + (n2 / n1));
