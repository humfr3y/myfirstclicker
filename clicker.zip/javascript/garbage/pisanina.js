document.write("Eito pahnet pisunami negrov!");
console.log("negri vse pidorasi");
console.error("где-то валяется фарш из бати сракса!");
console.warn("сракс метнет стрелку и соснёт хуйца")

// <br>

// function chooseVersionText() {
//     if (data == 1) {
//         desc00 = `<b>18.12.2022 | My1stClicker 0.0 | Нулевое обновление. (Кодовое название: NULL):</b><br>
//     - НОВАЯ МЕХАНИКА! Вам нужно нажимать на кнопку, чтобы получать α-монеты.<br>
//     - НОВЫЕ УЛУЧШЕНИЯ! Первое улучшение увеличивает кол-во получаемых α-монет на 1, второе усиливает бонус первого на 10%.<br>
//     - Некоторые баги, например, иногда не срабатывает бонус 2 улучшения. Не знаю почему.<br><br>
//     [Комментарий разработчика]<br>
//     Это моя первая игра и я потратил на нее некоторое время. Ну, на самом деле это моя вторая игра, первым был мод.
//     Без понятия, продолжать мне разработку или нет.`;
//     }
//     else {
//         desc00 = `<b>18.12.2022 | My 1st Clicker 0.0. Null Update (Codename: NULL):</b><br>
//     - NEW MECHANIC! You need to clicking on the button for gaining α-coins.<br>
//     - NEW 2 UPGRADES! First increases α-coin per click by 1, second increases bonus of first one by 10%.<br>
//     - Some bugs like you sometimes cant get bonus from 2nd upgrade. Idk why.<br><br>
//     [Dev comment]<br>
//     This is a first game made by me from scratch, and i spent for it a some time. Well it's actually my second game, but that first made it's just mod.
//     Idk if i want to continue it.`;
//     }

//     if (data == 1) {
//         desc01 = `<b>19.12.2022 | My1stClicker 0.1 | Графическое обновление. (Кодовое название: BUTTON):</b><br>
//     - Теперь вместо депрессивной кнопки будет более яркая иконка α-монетки.<br>
//     - Кнопки покупок стали чуть лучше.<br>
//     - Небольшое ослабление формулы цены улучшений.<br><br>
//     [Комментарий разработчика]<br>
//     Ну, я продолжил и сделал что-то хорошее, даже с нулевыми навыками в HTML и CSS. Это очень впечатляюще. Я думаю, стоит изучить их обоих позже.<br>
//     Есть еще очень много вещей, которые мне предстоит сделать и которые я не смогу сделать, пока не разберусь. Также я пытался добавить иконки для кнопок, но при покупке улучшения они пропадают, я должен их как-то связать... `;
//     }
//     else {
//         desc01 = `<b>19.12.2022 | My 1st clicker 0.1. Graphic Update (Codename: BUTTON):</b><br>
// - Game has beautiful α-coin icon instead of depressed button.<br>
// - Upgrades buttons became a little better.<br>
// - A little decreasing of cost formula for upgrades.<br><br>
// [Dev comment]<br>
// Well i continued it and i did something good even with zero html and css skills, it's really impressive and i really should learn them both later.<br>
// There a really much things which i should do, and which i dont know how to do. Also i tried to add icons for buttons but when you buying upgrades it disappears, i should to link it somehow...`;
//     }

//     if (data == 1) {
//         desc02 = `<b>20.12.2022 | My1stClicker 0.2 | Обновление сохранений. (Кодовое название: SAVE):</b><br>
//     - Теперь есть возможность сохраняться и загружать сохранения (при этом, текст в улучшениях будет сброшен)<br>
//     - Добавлена кнопка журнала изменений.<br>
//     - Теперь .css код перемещен в отдельный файл.<br>
//     - Изменения кнопки БЕТА (?)<br><br>
//     [Комментарий разработчика]<br>
//     На самом деле, я сделал это обновление за один день. Самое забавное - я потратил немного времени на реализацию сохранений. Следующая цель: новые интересные обновления.`;
//     }
//     else {
//         desc02 = `<b>20.12.2022 | My 1st clicker 0.2. SAVE Update (Codename: Save):</b><br>
// - You can finally save n load the game by bottom buttons (but text for upgrades doesn't refresh).<br>
// - Changelog button added.<br>
// - Now CSS lines have moved to a separate .css file.<br>
// - BETA button changes. <br><br>
// [Dev comment]<br>
// Actually i did it in one day but now i have 20th December. Most funny thing that i spent for saving not much time. Next goal is new interesting upgrades.`;
//     }

//     if (data == 1) {
//         desc03 = `<b>28.01.2023 | My1stClicker 0.3 | Больше графических обновлений. (Кодовое название: CHEST):</b><br>
//     - НОВОЕ УЛУЧШЕНИЕ! Третье улучшение усиливает число получаемых α-монет на 5%.<br>
//     - БОЛЬШОЕ ОБНОВЛЕНИЕ ДИЗАЙНА! Теперь в игре есть задний фон и новый шрифт.<br>
//     - АВТО-СОХРАНЕНИЕ! Теперь есть возможность включить автоматические сохранение, и оно будет срабатывать каждые 10 секунд (выключается при перезаходе).<br>
//     - Перекрашенные кнопки (пожалуйста, дайте идей насчет нижних кнопок).<br>
//     - Изменен спрайт α-монеты, теперь она лучше подходит к заднему фону.<br>
//     - Улучшенная формула роста цен.<br>
//     - Усовершенствоваван текст в улучшениях.<br>
//     - Теперь цена улучшений сохраняется и будет загружена в случае загрузки прогресса.<br><br>
//     [Комментарий разработчика]<br>
//     Наконец-то вернулся к игре и сделал неплохое обновление. Добавлен задний фон и многое другое. Следующая цель: новые специальные улучшения.`;
//     }
//     else {
//         desc03 = `<b>28.01.2023 | My 1st clicker 0.3. More Graphic Update (Codename: CHEST):</b><br>
// - NEW UPGRADE! Third upgrade can boost yourα-coin gain by 5%.<br>
// - MAJOR DESIGN UPDATE! Game has some bg and font.<br>
// - AUTOSAVING! You can enable autosave, and it will save every 10 sec (When you load it does disable it).<br>
// - Recolored buttons (give me ideas about bottom one please idk what to do).<br>
// - Changedα-coin icon, it suits bg better.<br>
// - Changed cost formula to good one (logarithm goes brrr).<br>
// - Improved upgrade texts.<br>
// - Save n load contains prices.<br><br>
// [Dev comment]<br>
// Finally comeback for it and did not bad update tho. Added bg and some stuff. Next goal is new special upgrades.`;
//     }

//     if (data == 1) {
//         desc04 = `<b>29.01.2023 | My1stClicker 0.4 | Простое обновление (Кодовое название: SIMPLE):</b><br>
//     - НОВЫЙ ТИП УЛУЧШЕНИЙ - ЕДИЧИНЫЙ. Их можно купить только один раз, верно?<br>
//     - 3 НОВЫХ УЛУЧШЕНИЯ! Первое увеличивает кол-во α-монет за нажатие в зависимости от общего кол-ва α-монет, второе удваивает получение α-монет, третье усиливает бонус второго в зависимости от кол-ва первого.<br>
//     - Текст в игре теперь не разделен через / и он имеет один язык в зависимости от выбора языка.<br>
//     - Исправлена "прыгающая" кнопка автосохранения.<br>
//     - Усилена формула роста цены улучшений.<br>
//     - Игра автоматически загружает прогресс при перезагрузке страницы.<br>
//     - Теперь есть 2 журнала изменений: русский и английский. <br>
//     - НОВАЯ КНОПКА - Сбросить игру. Она удаляет все сохранения и перезапускает игру.<br>
//     - После перезагрузки улучшения не сбрасываются.<br>
//     - Цвет кнопок становится красным, когда вы не можете купить улучшение. Кнопки становятся слегка ярче, когда курсор наводится на нее и улучшение можно купить. Также яркость влияет на нижние кнопки.<br><br>
//     [Комментарий разработчика]<br>
//     Это еще одно отличное для дизайна обновление (по крайней мере для меня), следующая цель - вкладки, но если быть честным, я без понятия как их делать, и вероятно очередное QoL обновление. 👀`;
//     }
//     else {
//         desc04 = `<b>29.01.2023 | My1stClicker 0.4. Simple Update (Codename: SIMPLE):</b><br>
// - NEW TYPE OF UPGRADES - SINGLE. You can buy them only once. Right?<br>
// - 3 NEW UPGRADES! First increases gain based on total α-coins, second doublesα-coin gain and third increases bonus of 2nd upgrade based on amount of 1st.<br>
// - Text in game has own language and doesn't have two languages like rus / eng.<br>
// - Fixed autosave jumping button.<br>
// - Buffed cost formula for upgrades.<br>
// - Game autoloads progress after page refresh.<br>
// - Now there is two changelogs: russian and english. <br>
// - NEW BUTTON - HARD RESET. It can blow up your saved files and reset everything in the game
// - After load text stays as before save.<br>
// - Upgrade's buttons has red color when you cant afford it and sligtly brightness when you hover on it and you can buy it. Also brightness affects on bottom buttons.<br><br>
// [Dev comment]<br>
// This is one more great upgrade for design (at least for me), next goals are tabs, honestly idk how to do them. And probably one more QoL upgrade :eyes:`;
//     }

//     if (data == 1) {
//         desc05 = `<b>08.02.2023 | My1stClicker 0.5 | Революционное обновление (Кодовое название: ANTIMATTER):</b><br>
//     Изменения в дизайне:<br>
//     - ПОЛНЫЙ РЕДИЗАЙН ИГРЫ! Простой черноватый задний фон, кнопки с различными эффектами в зависимости от их состояния (наведение, недостаточно денег или можно купить), новая иконка монетки.<br>
//     - ИЗМЕНЕНИЯ ИНТЕРФЕЙСА! Ты можешь переключаться между 4 вкладками.<br>
//     - Кнопки Сохранения, Загрузки, Журнала изменений, Сброса игры, Авто-сохранения были пересены во вкладку с настройками.<br>
//     - Улучшен текст кнопок. Добавлены названия улучшений.<br>
//     - Улучшен текст с количеством монет. Количество монет за нажатие появляется отдельно чуть ниже.<br>
//     - Добавлена информация с версией игры, главной целью и благодарностями.<br>
//     - Монеты стали α-монетами.<br>
//     - Текст 1го, 2го, 4го, 6го улучшения обновляется автоматически.<br>
//     - Русский перевод для Журнала изменений стал лучше.<br>
//     Изменения в геймплее:<br>
//     - Официальная цель - 1,000,000,000 α-монет. При достижении этой цели появляется специальное окно.<br>
//     - Полностью изменена формула стоимости для 1-3 улучшений. Теперь здесь не будет инфляции, я надеюсь.<br>
//     - Усилен эффект 3го улучшения +1.05 to x1.05 (умножается само на себя).<br>
//     - Усилен эффект 4го улучшения (log(x)/2 -> log(x)).<br>
//     - Усилен эффект 6го улучшения (log(x) -> log(x)^2).<br>
//     - Снижение стоимости 6го улучшения (15,000,000 -> 5,000,000).<br><br>
//     [Комментарий разработчика]<br>
//     Это безумно, я потратил на это неделю. Ну, я тратил несколько часов каждый день и 0.5 наконец-то вышла! Наслаждайтесь первым Революционным обновлением. Если честно, я хотел сделать такой стиль ранее, однако, почему-то я отбросил эту идею. Следующее обновление будет иметь эту неизвестную вещь.`;
//     }
//     else {
//         desc05 = `<b>08.02.2023 | My1stClicker 0.5. Revolution Update (Codename: ANTIMATTER):</b><br>
// Design changes:<br>
// - FULL REDESIGN OF GAME! Simple black bg, buttons with disabled/enabled/hovered functions, new coin icon.<br>
// - INTERFACE CHANGE! You can select 4 tabs: settings, clicker, ?????? and info.<br>
// - Save, Load, Changelog, Hard reset, Autosave buttons replaced to Settings tab.<br>
// - Improved button text. Added titles.<br>
// - Improved coin text. "You have earned" text replaced separately.<br>
// - Added information text with version, main goal, and thanks.<br>
// - Coins became α-coins.<br>
// - 1st, 2nd, 4th, 6th upgrades text updates every purchasing.<br>
// - Better russian translate for changelogru.<br>
// Gameplay changes:<br>
// - Added official goal - 1,000,000,000 α-coins. If you achieve this goal, there appears special tab.<br>
// - Fully changed cost formula for 1-3 upgrades. Now there is no inflation. I hope.<br>
// - Buffed 3rd upgrade effect from +1.05 to x1.05 (multiplies itself).<br>
// - Buffed 4th upgrade effect (log(x)/2 -> log(x)).<br>
// - Buffed 6th upgrade effect (log(x) -> log(x)^2).<br>
// - Reduced 6th upgrade cost (15,000,000 -> 5,000,000).<br><br>
// [Dev comment]<br>
// That's crazy, i've spent for it a week. Well I spent some hours everyday and finally 0.5 came out. Enjoy the first Revolution Update. Tbh i wanted to do this style earlier, but for some reason i didnt do it. Next update will contain that unknown thing.`;
//     }

//     if (data == 1) {
//         desc051 = `<b>15.02.2023 | My1stClicker 0.5.1:</b><br>
//     Изменения в дизайне:<br>
//     - Наконец-то верхние кнопки и кнопки улучшения стали по центру.<br>
//     - Покупка Продуктивности обновляет Небольшую Инвестицию без Сверхпродуктивности (но всё ещё иногда не обновляется, однако это проблема в формуле).<br>
//     - Автосохранение включается на старте игры.<br>
//     - Огромная оптимизация кода для меня (Вообще, обновление было именно про это).<br>
//     - Внимание! Обновление не стабильное и не тестировалось мною, потому что у меня уже час ночи и пора спать. Вы можете протестировать и прислать мне все ошибки игры в дискорде Humf#9778 или же в телеграме @nerdfrey (@humfr3y).<br><br>
//     [Комментарий разработчика]<br>
//     Простите за столь маленькое обновление, дело в том что я изучаю по видео HTML, CSS, Vue.js (сейчас учу CSS), так что я не трачу время зря! Я просто хочу сделать отличный интерфейс, особенно, для следующего обновления. Вы можете заметить в консоли что в 0.6 будет добавлен Престиж. Однако что это принесёт? Думайте.`;
//     }
//     else {
//         desc051 = `<b>15.02.2023 | My1stClicker 0.5.1:</b><br>
// Design changes:<br>
// - Finally top and upgrades buttons were centered.<br>
// - Now buying Productivity updates Small Investment (but does it weirdly sometimes doesn't but its formula issue).<br>
// - Autosaving turned on after starting new game.<br>
// - Great optimization of code for me. (Actually this update about it).<br>
// - Notice: update unstable because i have almost 1 AM and can't test it rn. You can do it yourself and send me some issues in discord Humf#9778.<br><br>
// [Dev comment]<br>
// Sorry for the little update, I'm just learning a little HTML, CSS and Vue.js (rn at CSS), so that's not procrastination! I wanna make fine interface especially for the next update. Ok you can check through console new 0.6 thing will be Prestige ofc. But what'll it make? Stay tuned!`;
//     }

//     if (data == 1) {
//         desc06 = `<b>09.03.2023 | Цифровой Бог 0.6 | Обновление Престижа (Кодовое название: PRESTIGE):</b><br>
// Изменения в интерфейсе:<br>
// - Изменено имя игры на Цифровой Бог. Причина в том что игра будет кликером только в самом начале, а после некоторых улучшений вы сможете получать монеты автоматически и в игре больше негде будет кликать. У меня была идея сделать получение алмазов кликером но это было бы очень странно.<br>
// - Добавлена иконка страницы. Молния. Бог. Зевс.<br>
// - Кнопки и текст стал меньше.<br>
// - Настройки и Статистика имеют заголовки.<br>
// - Улушчено расположение кнопок настроек.<br>
// - Убрана кнопка "?????", теперь то что в ней появится при 1е9 монет.<br>
// - Улучшен текст в статистике.<br>
// - Основные улучшения не имеют оттенков.<br>
// - Сохранения и загрузки используют метод Stringify.<br>
// - Кнопки вкладок не имеют "активного режима", однако теперь при наведении на них меняется цвет.<br>
// - Небольшие улучшения.<br>
// Изменения в особенностях игры:<br>
// - ИМПОРТ И ЭКСПОРТ! Вы можете создать зашифрованный в base64 текст и он будет содержать все значения игры. С этим вы можете создать свой сэйвбанк или делиться с друзьями!<br>
// - СМЕНА ЯЗЫКА! Вы можете менять язык без перезагрузки страницы.<br>
// - Убрано уведомление о смене языка при загрузке страницы.<br>
// - Теперь Сброс Игры не перезагружает страницу.<br>
// - Значения после 1 миллиона имеют научное обозначение.<br>
// - Исправлен баг при котором нельзя было отключить автосохранение.<br>
// Изменения в геймплее:<br>
// - ПРЕСТИЖ! Сбросьте весь прогресс чтобы получить алмазы, которые дают бонус к получению монет.<br>
// - АЛМАЗЫ! Потратьте их на различные улучшения чтобы продвигаться ещё быстрее!<br>
// - НОВЫЕ ПРЕСТИЖНЫЕ УЛУЧШЕНИЯ! Они имеют 4 слоя: Покупаемые, Автоматизации, Единичные, и последний из них это Открывающие, которые открывают следующий слой улучшений, как правило они всегда последние в их ряду.<br>
// - АВТОМАТИЗАЦИЯ! После покупок 5-7 Улучшений Престижа вы можете автоматически покупать улучшения или получать монеты в секунду.<br>
// - Добавлены софткапы для монет на е20 и е35 а также для алмазов на 4000 и 100000.<br>
// - Немного улучшена формула для Сверхпродуктивности.<br>
// - Увеличен рост цен для 1-3 Основных Улучшений.<br><br>
// [Комментарий разработчика]<br>
// Неужели! Спустя две недели я наконец-то смог завершить это обновление. Это самое глобальное обновление за историю игры. Я столько повидал багов и ошибок, и столько, или чуть меньше, я решил. Самым тяжёлым для меня было понять как сделать так чтобы после престижа у 4-6 улучшений пропадал синий цвет (как будто улучшение больше не куплено). Я потратил на это два дня, и как раз это стало причиной забросить игру на две недели. Что касается остальных багов то это было что-то типо "проблема на проблеме", когда, при решении одной, появлялась другая, кстати это стало причиной исправить ту ошибку. Я захотел менять язык при нажатии на кнопку, и так вышло что пришлось страдать и исправлять этот баг. Ну на деле это оказалось не так сложно. Я очень рад что смог завершить и не забросить это обновление, и буду рад что вы хотя бы поиграете немного в неё и что те труды, то время, которое я тратил делая игру (а это по 3-7 часов в день в зависимости от желания) не пройдут напрасно. Что же касается названия игры то тут довольно легко. Давайте я составлю мини-лор: вы, нищее создание, стремитесь стать богом в виртуальной реальности, однако вам нужно для этого невероятная мощь Бога, которая кроется в непримечательных монетах которые вы собираете во время игры а затем тратите чтобы получать ещё больше. Каждая валюта делает вас сильнее и могущественнее. Однако всё ли так будет просто? Поможет ли в этот раз Фортуна?`;
//     }
//     else {
//         desc06 = `<b>09.03.2023 | Digital God 0.6. Prestige Update (Codename: PRESTIGE):</b><br>
// Design changes:<br>
// - Changed game name to Digital God 0.6. Reason: Game will be a clicker only at start, then after some upgrade money gain become automated and there is no will be any clicking things. I had idea make diamond gain clickable but that'll be weird.<br>
// - Added page icon. Lightning. God. Zeus.<br>
// - Buttons and text got smaller.<br>
// - Settings and Statistics has title.<br>
// - Improved settings buttons.<br>
// - Removed "?????" button, now it'll appear at 1e9 coins.<br>
// - Improved Stats text.<br>
// - Main upgrades doesn't have shades anymore.<br>
// - Saving and Loading now using stringify method.<br>
// - Tab buttons no longer has "active mode", but they changing color while hover.<br>
// - Some little improvements.<br>
// Feature changes:<br>
// - IMPORT AND EXPORT! You can make base64-encoded text and it'll contain all your values. You can create your savebank or share with your friends!<br>
// - CHANGE LANGUAGE! You can change language without refreshing page.<br>
// - Removed confirmation for changing message while refreshing page.<br>
// - Now Hard Reset doesn't refreshing page.<br>
// - Values has scientific notation after 1,000,000 number.<br>
// - Fixed autosaving was unchangeable.<br>
// Gameplay changes:<br>
// - PRESTIGE! Reset whole progress to get diamonds, which boosts your production!<br>
// - DIAMONDS! Spend them for new prestige upgrades which can boost your progress even further!<br>
// - NEW PRESTIGE UPGRADES! They have 4 layers: Buyable, Automatic, Single and last of them is Unlockable upgrades which unlocking next layers of prestige upgrades, they're always last in them row.<br>
// - AUTOMATION! After buying 5-7 Prestige Upgrades you will be able to autobuy upgrades or gain coins per second.<br>
// - Added softcaps for coin gain at e20 and e35 and for diamonds gain at 4000 and 100000.<br>
// - Slightly better formula for Superproductivity.<br>
// - Buffed cost formula for 1-3 Main Upgrades.<br><br>
// [Dev comment]<br>
// Finally! After 2 weeks I finish this update. It's biggest update in the history of game. I have seen so many bugs and errors, and so much or a little less i solved. The hardest thing for me was to figure out how to remove blue (purchased) color for 4-6 upgrades. I spent two days on this, and it's the reason why i abandoned the game for 2 weeks. The rest bugs were "Problem on a problem" when after solving one, another appeared, btw it was the reason to fix that "hardest" bug. I wanted to make changing language button, and it turned out to suffer and fix that bug. Well it wasn't hard. I'm glad i finished this update and didn't abandon it. I'll be really glad if you play it at least for a little and those works, that time i spent for making update (3-7 hours per day) will not pass in vain. What about name of the game? Let me explain with small lore: You, a poor creature, aspire to become a God in virtual reality, but you need incredible power of God, which lies in the some coins that you collect during the game and then spend to get even more. Each currency makes you stronger and more powerful. However will everything will be simple? Will Fortune help this time?`;
//     }

//     if (data == 1) {
//         desc07 = `<b>15.05.2023 | Цифровой Бог 0.7 | Желанное Обновление (Кодовое название: QOL):</b><br>
//     Изменения в интерфейсе:<br>
//     - Количество монет, алмазов и сама кнопка сброса престижа теперь отображается в "шапке" игры.<br>
//     - Слегка изменены кнопки. Размер кнопок улучшений и расположение кнопок настроек.<br>
//     - Добавлены подвкладки в "Информация".<br>
//     - Добавлены уведомления при сохранении, загрузке, импорте, экспорте, сбросе игры.<br>
//     - Исправлено отображение эффектов некоторых улучшений.<br>
//     - Новая статистика: Время проведённое в игре/престиже и также самый быстрый престиж.<br>
//     Изменения в особенностях игры:<br>
//     - КНОПКА "КУПИТЬ ВСЁ"! Теперь вы можете покупать все улучшения одним нажатием кнопки. И теперь вам... остаётся лишь нажимать на монетку.<br>
//     - Добавлена возможность делать сброс Престижа клавишей "P" (английская) и покупать всё клавишей "М".<br>
//     - Экспорт теперь происходит в виде сохранения файла на ваше устройство (однако он всё ещё копируется в буфер обмена).<br>
//     Изменения в геймплее:<br>
//     - Большинство улучшений Престижа были ослаблены, однако некоторые были слегка усилены.<br>
//     - Более жёсткий софткап алмазов.<br><br>
//     [Комментарий разработчика]<br>
//     Да, такое маленькое обновление спустя 2 месяца, я игрой начал заниматься буквально вчера, просто что-то не было желания. Точнее оно было, но появились кое-какие трудности, и по итогу неделя выпала. Однако, 0.8 изменит абсолютно всё, ведь это обновление будет касаться Монет. Улучшения, механика кликера и т.д. изменятся и всё будет совсем по другому. Тоже самое касается и 0.9 - Обновлением Престижа 2! Когда я буду заниматься этим? Возможно завтра, я не знаю.`;
//     }
//     else {
//         desc07 = `<b>15.05.2023 | Digital God 0.7 | "You really want it" Update (Codename: QOL):</b><br>
// Design changes:<br>
// - Amount of coins, diamonds, and prestige reset button now displayed in header.<br>
// - Slightly changed buttons. Upgrade buttons size and settings buttons location.<br>
// - Added subtabs in Info page.<br>
// - Added notifications when saving, loading, importing, exporting, hard reseting.<br>
// - Fixed display of some upgrades effects.<br>
// - New stats: Time spent in the game/prestige, fastest prestige.<br>
// Feature changes:<br>
// - "BUY ALL" BUTTON! Now you can buy all stuff just by clicking that one button.<br>
// - Added possibility to make Prestige Reset by pressing "P" and Max Buy by pressing "M".<br>
// - Export always saves text file with save in your device (it's still copies into your clipboard).<br>
// Gameplay changes:<br>
// - Many Prestige Upgrades has been nerfed. But some of them are got a slightly buff.<br>
// - More roughly diamonds gain softcap.<br><br>
// [Dev comment]<br>
// Yeah, so small update after 2 months, cuz i started to make it yesterday, i just didn't want to do it. Well i actually did, but some troubles appeared and i couldn't make something. But 0.8 will change EVERYTHING, because it's Coins Update! New upgrades, mechanics changing and more! 0.9 also takes something like Prestige Update 2! Well, when i'll start to do it? Idk.`;
//     }

//     if (data == 1) {
//         desc071 = `<b>17.05.2023 | Цифровой Бог 0.7.1:</b><br>
// Изменения в интерфейсе:<br>
// - Добавлена частичка α- ко всем надписям "монет" которые были без неё.<br>
// - Исправлен текст на кнопке Престижа.<br>
// Изменения в особенностях игры:<br>
// - Добавлена статистика с 10 последними Престижами.<br>
// - Добавлена возможность импорта прямо из файла.<br>
// - Журнал изменений теперь находится в самой игре а не в отдельном файле.<br>
// - Исправлен баг при котором постоянно появлялось сообщение о достижении цели игры.<br>
// Изменения в геймплее:<br>
// - Исправлен баг в котором при нажатии на автоматизации игра просто намертво залагала.<br>
// - Увеличен софткап на получение алмазов.<br>
// - Понижены эффекты улучшений Престижа.<br><br>
// [Комментарий разработчика]<br>
// Я сильно устал пока разбирался с теми 10 последними престижами. Очень долго пытался сделать так чтобы строки сохранялись и загружались без проблем. Однако там всё ещё есть над чем работать. Следующее обновление - 0.8.`;
//     }
//     else {
//         desc071 = `<b>17.05.2023 | Digital God 0.7.1:</b><br>
//         Design changes:<br>
//         - Added "α-" to all "coins" strings without it.<br>
//         - Fixed Prestige reset button text<br>
//         Feature changes:<br>
//         - Added statistics with latest 10 Prestige resets<br>
//         - Added possibility to import from the file.<br>
//         - Changelog appears in game itself not in separate file.<br>
//         - Fixed bug which sends you annoying message about completing the game.<br>
//         Gameplay changes:<br>
//         - Fixed bug where you could turn on automation and it'll freeze the game.<br>
//         - Increased diamonds gain softcap.<br>
//         - Decreased Prestige upgrades effects.<br><br>
//         [Dev Comment]<br>
//         I'm really tired, that latest 10 Prestige resets feature took a lot of time, cuz i couldn't to export their strings. Next update - 0.8.`;
//     }
// }


// function changedLanguage () {
//     chooseVersionText();
//     if (data==1) {settingsTab.innerHTML = "Настройки"}
//     else {settingsTab.innerHTML = "Settings"}
//     if (data==1) {mainTab.innerHTML = "Кликер"}
//     else {mainTab.innerHTML = "Clicker"}
//     if (data==1) {prestigeTab.innerHTML = "Престиж"}
//     else {prestigeTab.innerHTML = "Prestige"}
//     if (data==1) {infoTab.innerHTML = "Информация"}
//     else {infoTab.innerHTML = "Information"}
//     if (data==1) {autoTab.innerHTML = "Автоматизация"}
//     else {autoTab.innerHTML = "Automation"}
//     if (data==1) {fortuneTab.innerHTML = "Фортуна"}
//     else {fortuneTab.innerHTML = "Fortune"}
//     if (data==1) {settingsTab.innerHTML = "Настройки"}
//     else {settingsTab.innerHTML = "Settings"}
    
//     if (data==1) {maxbuy.innerHTML = "Купить всё"}
//     else {maxbuy.innerHTML = "Max buy"}
    
//     if (data==1) {statisticsTab.innerHTML = "Статистика"}
//     else {statisticsTab.innerHTML = "Statistics"}
//     if (data==1) {aboutGameTab.innerHTML = "Об игре"}
//     else {aboutGameTab.innerHTML = "About game"}
//     if (data==1) {latestPrestigesTab.innerHTML = "Сбросы Престижа"}
//     else {latestPrestigesTab.innerHTML = "Prestige resets"}
    
//     loadStats.call()
//     if (data==1) {coinGain.innerHTML = money.toFixed(0) + " α-монет. Нажмите на α-монету."} 
//     else {coinGain.innerHTML = money.toFixed(0) + " α-coins. Click on the α-coin."}
    
//     if (data==1) {savingGame.innerHTML = "Сохранить игру"} 
//     else {savingGame.innerHTML = "Save game"}
//     if (data==1) {loadingGame.innerHTML = "Загрузить игру"} 
//     else {loadingGame.innerHTML = "Load game"}
//     if (data==1) {autoSavingGame.innerHTML = "Автосохранение вкл."}
//     else {autoSavingGame.innerHTML = "Autosave on."}
//     if (data==1) {changingLanguage.innerHTML = "Сменить язык на английский"}
//     else {changingLanguage.innerHTML = "Switch language to russian"}
//     if (data==1) {impSave.innerHTML = "Импорт"}
//     else {impSave.innerHTML = "Import"}
//     if (data==1) {document.querySelector('label.loadfile').innerHTML = 'Импортировать из файла'}
//     else {document.querySelector('label.loadfile').innerHTML = 'Import from the file'}
//     if (data==1) {expSave.innerHTML = "Экспорт"}
//     else {expSave.innerHTML = "Export"}
//     if (data==1) {changelogOpen.innerHTML = "Журнал изменений"}
//     else {changelogOpen.innerHTML = "Changelog"}
//     if (data==1) {changelogTitle.innerHTML = "Журнал изменений"}
//     else {changelogTitle.innerHTML = "Changelog"}
//     if (data==1) {versionDescription.innerHTML = "Нажмите на версию!"}
//     else {versionDescription.innerHTML = "Click on the version!"}
//     if (data==1) {hardRes.innerHTML = "Сбросить игру"}
//     else {hardRes.innerHTML = "Reset the game"}
    
//     if (data==1) {playMore.innerHTML = "Играть дальше"}
//     else {playMore.innerHTML = "Play more"}
    
//     if (data==1) {doPrestige.innerHTML = "Стать престижным"}
//     else {doPrestige.innerHTML = "Become prestige"}
    
//     if (data==1) {settingsTitle.innerHTML = "Настройки"}
//     else {settingsTitle.innerHTML = "Settings"}
//     if (data==1) {statsTitle.innerHTML = "Статистика"}
//     else {statsTitle.innerHTML = "Statistics"}
//     if (data==1) {latestPrestigesTitle.innerHTML = "10 последних сбросов Престижа"}
//     else {latestPrestigesTitle.innerHTML = "Latest 10 Prestige resets"}
    
//     if (data==1) {autoBuy1to3.innerHTML = "Автопокупка 1-3 улучшений"}
//     else {autoBuy1to3.innerHTML = "1-3 upgrades autobuyer"}
//     if (data==1) {autoBuy4to6.innerHTML = "Автопокупка 4-6 улучшений"}
//     else {autoBuy4to6.innerHTML = "4-6 upgrades autobuyer"}
//     if (data==1) {autoMoney.innerHTML = "Автополучение α-монет"}
//     else {autoMoney.innerHTML = "Money autogain"}
    
//     if (data==1) {fortuneNotImplemented.innerHTML = "Не реализовано!"}
//     else {fortuneNotImplemented.innerHTML = "Not implemented!"}
    
//     if (data==1) {aboutGame.innerHTML = "Об игре: <br><br> Цифровой Бог 0.7.1 <br> Главная цель: 1e100 α-монет. <br><br> Спасибо Орехус#7698 за перевод на русский. <br> Спасибо также всем кто хоть немного поиграл в игру."}
//     else {aboutGame.innerHTML = "About game: <br> <br> Digital God 0.7.1 <br> Main goal: 1e100 α-coins. <br><br> Thanks Орехус#7698 for russian translate. <br> Thanks everyone for playing."}
    
//     if (data==1) {endScreen.innerHTML = "Поздравляем, вы прошли игру! Однако, только в этой версии. В следующих обновлениях будет всё больше новых вещей. Если будешь ещё играть нажимай \"Играть Дальше!\""}
//     else {endScreen.innerHTML = "Congratulations, you have completed game! However, only in this version. In the future there will be many new things. If you wanna play more press \"Play More!\""}
//     }
//     changedLanguage.call()
